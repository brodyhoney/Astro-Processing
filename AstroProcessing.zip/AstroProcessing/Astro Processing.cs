﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AstroProcessing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private static int max = 24;
        private static int[] number_array = new int[max];
        private void Display()
        {
            ListBoxNumbers.Items.Clear();


            for(int i = 0; i < max; i++)
            {
                ListBoxNumbers.Items.Add(number_array[i]);
            }
        }

        private void FillArray()
        {
            Random rand = new Random();
            for (int i = 0; i < max; i++)
            {
                number_array[i] = rand.Next(10, 99);
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            FillArray();
            Display();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ListBoxNumbers.Items.Add(TextBox.Text);
            TextBox.Clear();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult delName = MessageBox.Show("Are you sure you wish to remove the selected item?", "Delete Confirmation",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (delName == DialogResult.Yes)
            {
                ListBoxNumbers.Items.Remove(ListBoxNumbers.SelectedItem);
            }
        }

    }
}
