﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AstroProcessing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        public static int max = 24;
        public static int[] number_array = new int[max];
        #region Utilities
        private void Display()
        {
            ListBoxNumbers.Items.Clear();


            foreach(int num in number_array)
            {
                if (num > 0)
                {
                    ListBoxNumbers.Items.Add(num);
                }
            }
        }

        private void FillArray()
        {
            Random rand = new Random();
            for (int i = 0; i < number_array.Length; i++)
            {
                number_array[i] = rand.Next(10, 99);
            }
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            FillArray();
            Display();
            TextBox.Focus();
            toolStripStatusLabel1.Text = "Array filled with random integers";
        }
        #endregion

        #region AddEditDelete
        private void btnAdd_Click(object sender, EventArgs e)
        {

            var numbers_List = number_array.ToList();
            numbers_List.Add(Int32.Parse(TextBox.Text));
            number_array = numbers_List.ToArray();
            /*number_array[nextEmpty] = Int32.Parse(TextBox.Text);
            nextEmpty++;*/
            TextBox.Clear();
            TextBox.Focus();
            Display();
            toolStripStatusLabel1.Text = "Item added";
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            int Selected_Index = ListBoxNumbers.SelectedIndex;
            if ((Selected_Index > -1)&&(TextBox.Text!=""))//Checks whether an index is selected or if the textbox is empty
            {
                DialogResult editItem = MessageBox.Show("Are you sure you wish to edit the selected item?", "Edit Confirmation",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (editItem == DialogResult.Yes)
                {
                    //ListBoxNumbers.Items.Remove(ListBoxNumbers.SelectedItem);//Removes item from the list box
                    number_array[Selected_Index] = Int32.Parse(TextBox.Text);//Adds the edited item to the array
                    TextBox.Clear();
                    Display();
                }
            }
            else
            {
                if (Selected_Index == -1)
                {
                    MessageBox.Show("Please select an item to be edited.");
                }
                else
                {
                    MessageBox.Show("Text box is empty");
                }
            }
            TextBox.Focus();
            toolStripStatusLabel1.Text = "Item edited";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            
            if(ListBoxNumbers.SelectedIndex > -1)
            {
                DialogResult delNum = MessageBox.Show("Are you sure you wish to remove the selected item?", "Delete Confirmation",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (delNum == DialogResult.Yes)
                {
                    var numbers_List= number_array.ToList();//Converts the array to a list https://stackoverflow.com/questions/496896/how-to-delete-an-element-from-an-array-in-c-sharp
                    numbers_List.RemoveAt(ListBoxNumbers.SelectedIndex);//Removes the element at the specified index
                    number_array = numbers_List.ToArray();//Converts list back to an array 
                }
            }
            else
            {
                MessageBox.Show("Nothing selected");
            }
            TextBox.Focus();
            Display();
            StatusStrip.Text = "Item deleted";

        }
        #endregion

        #region Sort&Search
        private void btnSort_Click(object sender, EventArgs e)
        {
            BubbleSort();
        }

        private void BubbleSort()
        {
            int temp = 0;
            for(int outer = 0; outer < number_array.Length-1; outer++)
            {
                for(int inner = 0; inner < number_array.Length-1; inner++)
                {
                    if(number_array[inner] > number_array[inner+1])
                    {
                        temp = number_array[inner + 1];
                        number_array[inner + 1] = number_array[inner];
                        number_array[inner] = temp;
                    }
                }
            }
            Display();
            toolStripStatusLabel1.Text = "Items sorted in ascending order";
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            BubbleSort();
            int low = 0;
            int high = number_array.Length;
            int mid=0;
            int target = Int32.Parse(TextBox.Text);
            mid = (low + high) / 2;
            
            while(low <= high)
            {
                
                mid = (low + high) / 2;
                if (number_array[mid] < target)
                {
                    low = mid + 1;
                }
                else if(number_array[mid] > target)
                {
                    high = mid - 1;
                }
                else
                {
                    MessageBox.Show("Item found");
                    break;
                }
                
                
            }

            if(number_array[mid] != target)
            {
                MessageBox.Show("Not found");
            }


        }








        #endregion

        
    }
}
