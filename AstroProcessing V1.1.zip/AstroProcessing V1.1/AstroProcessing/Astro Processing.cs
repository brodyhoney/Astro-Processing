﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Scrum Master: Brody Honey 
//Debug & Tester: Rishon Jacobs
//Client Requirements (CR)
//Program Functionality (PF)
//Date: 22/09/2021
//Version 1.1
//The program saves number of neutrino interactions per hour as integer values. 
//The program processes the hourly values by storing them in an array of size 24 and displaying it to the user.
//Buttons and listbox have been made to allow user to edit and manipulate data.


//CR: The name of the application should be Astronomical Processing.
namespace AstroProcessing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        //CR: All data is stored as integers in an array
        //PF: The array is of type integer
        //PF: The array has 24 elements to reflect the number of hours per day
        public static int max = 24; //
        public static int[] number_array = new int[max];
        #region Utilities                               
        private void Display()
        {
            ListBoxNumbers.Items.Clear();


            foreach(int num in number_array)
            {
                if (num > 0)
                {
                    ListBoxNumbers.Items.Add(num);
                }
            }
        }//Displays the array data

        private void FillArray()
        {
            Random rand = new Random();
            for (int i = 0; i < number_array.Length; i++)
            {
                number_array[i] = rand.Next(10, 99);
            }
        }//PF: The array is filled with random integers to simulate the data stream (numbers between 10 and 99).

        private void BtnFill_Click(object sender, EventArgs e)
        {
            FillArray();
            Display();
            TextBox.Focus();
            StatusStripLabel.Text = "Array filled with random integers";
        }//Fills the array with random integers 

        private void ListBoxNumbers_Click(object sender, EventArgs e)//Highlights clicked item
        {
            if (ListBoxNumbers.SelectedIndex != -1)
            {
                string currentItem = ListBoxNumbers.SelectedItem.ToString();
                int taskIndex = ListBoxNumbers.FindString(currentItem);
                TextBox.Text = number_array[taskIndex].ToString();
                TextBox.Focus();
            }
            else
                StatusStripLabel.Text = "No task selected";
        }
        private void TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            TextBox.MaxLength = 2;
        }//Prevents non-numeric input and limits input to two digits

        #endregion

        #region AddEditDelete
        //CR: There is an input field(text box) so data can be added.
        //PF: The program must be able to add data values.
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(TextBox.Text))
            {
                if (number_array.Length != max)
                {
                    var numbers_List = number_array.ToList();
                    numbers_List.Add(Int32.Parse(TextBox.Text));
                    number_array = numbers_List.ToArray();
                    TextBox.Clear();
                    TextBox.Focus();
                    Display();
                    StatusStripLabel.Text = "Item added";
                }
                else
                {
                    StatusStripLabel.Text = "Cannot add item, maximum size reached";
                    TextBox.Clear();
                    TextBox.Focus();
                }
            }
            else
            {
                StatusStripLabel.Text = "Text box is empty";//PF:The program must generate an error message if the text box is empty.
            }
        }//Allows data to be added to the array
        
        //CR: There is an input field (text box) so data can be edited.
        //PF: The program must be able to edit data values.
        private void BtnEdit_Click(object sender, EventArgs e)
        {
            int Selected_Index = ListBoxNumbers.SelectedIndex;
            if (!string.IsNullOrEmpty(TextBox.Text))
            {
                if (Selected_Index != -1)//Checks whether an index is selected or if the textbox is empty
                {
                    DialogResult editItem = MessageBox.Show("Are you sure you wish to edit the selected item?", "Edit Confirmation",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (editItem == DialogResult.Yes)
                    {
                        number_array[Selected_Index] = Int32.Parse(TextBox.Text);//Adds the edited item to the array
                        TextBox.Clear();
                        Display();
                        StatusStripLabel.Text = "Item edited";
                    }
                }
                else
                {
                    StatusStripLabel.Text = "Please select an item to be edited.";
                }
            }
            else
            {
                StatusStripLabel.Text = "Text box is empty";//PF:The program must generate an error message if the text box is empty.
            }
            TextBox.Focus();

        }//Allows data to be edited in the array

        //CR:There is an input field (text box) so data can be deleted.
        //PF:The program must be able to delete data values.
        private void BtnDelete_Click(object sender, EventArgs e)
        {
            
            if(ListBoxNumbers.SelectedIndex != -1)
            {
                DialogResult delNum = MessageBox.Show("Are you sure you wish to remove the selected item?", "Delete Confirmation",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (delNum == DialogResult.Yes)
                {
                    var numbers_List= number_array.ToList();//Converts the array to a list https://stackoverflow.com/questions/496896/how-to-delete-an-element-from-an-array-in-c-sharp
                    numbers_List.RemoveAt(ListBoxNumbers.SelectedIndex);//Removes the element at the specified index
                    number_array = numbers_List.ToArray();//Converts list back to an array 
                    StatusStrip.Text = "Item deleted";
                    TextBox.Clear();
                }
            }
            else
            {
                StatusStripLabel.Text = "Nothing selected";//PF:The program must generate an error message if the text box is empty.
            }
            TextBox.Focus();
            Display();


        }//Allows data to be deleted from the array
        #endregion

        #region Sort&Search
        //CR: There are buttons that can sort the data.

        private void BtnSort_Click(object sender, EventArgs e)
        {
            BubbleSort();
        }//Sorts the data in ascending order, calls BubbleSort() method
        
        //PF: The sort method must be coded using the Bubble Sort algorithm.
        private void BubbleSort()
        {
            int temp = 0;
            for(int outer = 0; outer < number_array.Length-1; outer++)
            {
                for(int inner = 0; inner < number_array.Length-1; inner++)
                {
                    if(number_array[inner] > number_array[inner+1])
                    {
                        temp = number_array[inner + 1];
                        number_array[inner + 1] = number_array[inner];
                        number_array[inner] = temp;
                    }
                }
            }
            Display();
            StatusStripLabel.Text = "Items sorted in ascending order";
        }

        //CR: There are buttons that can search the data.
        //PF: The search method must be coded using the Binary Search algorithm.
        //PF: A single text box is provided for the search input.
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(TextBox.Text))
            {
                BubbleSort();
                int low = 0;
                int high = number_array.Length;
                int mid = 0;
                string target = TextBox.Text;
                int num_target = Int32.Parse(target);
                if (!string.IsNullOrEmpty(TextBox.Text))
                {
                    while (low <= high)
                    {

                        mid = (low + high) / 2;
                        if (number_array[mid] < num_target)
                        {
                            low = mid + 1;
                        }
                        else if (number_array[mid] > num_target)
                        {
                            high = mid - 1;
                        }
                        else
                        {
                            //PF: The program must generate a message if the search is successful.
                            StatusStripLabel.Text = "Item " + number_array[mid] + " found at Index " + (Array.IndexOf(number_array, num_target) + 1);
                            ListBoxNumbers.SelectedIndex = mid;
                            break;
                        }
                    }
                }

                if (number_array[mid] != num_target)
                {
                    //PF: The program must generate an error message if the search is not successful.
                    StatusStripLabel.Text = "Not found";
                }
            }
            else
                StatusStripLabel.Text = "Text box is empty";
        }//Searches for specified item

        #endregion

        
    }
}
